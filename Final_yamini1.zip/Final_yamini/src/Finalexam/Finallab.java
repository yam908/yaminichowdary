package Finalexam;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Finallab {

	




	  WebDriver driver; 
	  @Test(priority=0)
	   public void launchBrowser()
	  	{
	  		  System.out.println("launching firefox browser");
	  		 
	  		  System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
	  		 driver= new FirefoxDriver();
	  		  driver.get("https://www.saucedemo.com/");
	  		   System.out.println("tt");
	  		 driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
	  		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
	  		try {
	  			Thread.sleep(2000);
	  		} catch (InterruptedException e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  		driver.findElement(By.xpath("//input[@id='login-button']")).click();
	  		
	  		try {
	  			Thread.sleep(3000);
	  		} catch (InterruptedException e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
		}
	@Test(priority=2)
	public void product()
	{
	
		driver.findElement(By.name("add-to-cart-sauce-labs-backpack")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("add-to-cart-sauce-labs-bike-light")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("add-to-cart-sauce-labs-bolt-t-shirt")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("add-to-cart-sauce-labs-fleece-jacket")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("add-to-cart-sauce-labs-onesie")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("add-to-cart-test.allthethings()-t-shirt-(red)")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		driver.findElement(By.className("shopping_cart_badge")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("checkout")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("first-name")).sendKeys("yamini"+Keys.TAB+"Kuntamukkala"+Keys.TAB+"H3W1P8");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("continue")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("finish")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("back-to-products")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
		public void Logout()
		{
		driver.findElement(By.id("logout_sidebar_link")).click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.quit();
		}
	
	
	}



